package testingDemo;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Amazonexample {
	
	public static void main(String[] args) {
		
		//Open the browser
		ChromeDriver driver=new ChromeDriver();
		
		//Maximize it
		driver.manage().window().maximize();
		
		//Navigate to https://www.amazon.in/
		driver.get("https://www.amazon.in/");
		
		//Click on ‘Mobiles’ in the navigation bar
		driver.findElement(By.linkText("Mobiles")).click();
		
		//Hover the pointer over ‘Mobiles & Accessories’
		WebElement mobile=driver.findElement(By.linkText("Mobiles & Accessories"));
		Actions actions=new Actions(driver);
		actions.moveToElement(mobile).build().perform();
		
		//Click on ‘Apple’ in the sub-menu
		driver.findElement(By.linkText("Apple")).click();
		
		//Click on first available phone.
		driver.findElement(By.xpath("(//div[contains(@class,'sg-col-inner')])[4]")).click();
		
		//Switch focus on new tab
		ArrayList<String> tabs=new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		
		
		
		//Click on ‘Buy Now’ button
		driver.findElement(By.id("buy-now-button")).click();
		
		//Verify user sees the text ‘Sign in’ on the last page.
		String ActualMsg=driver.findElement(By.className("a-spacing-small")).getText();
		String exceptedMsg="Sign in";
		
		
		if(exceptedMsg.equals(ActualMsg)) {
			System.out.print("Passed");
		}else {
			System.out.print("Fail");
		}
		
		//Close the browser.
		driver.quit();

		}

}
